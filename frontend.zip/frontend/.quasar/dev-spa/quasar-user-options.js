/* oxlint-disable */
/**
 * THIS FILE IS GENERATED AUTOMATICALLY.
 * DO NOT EDIT.
 *
 * You are probably looking on adding startup/initialization code.
 * Use "quasar new boot <name>" and add it there.
 * One boot file per concern. Then reference the file(s) in quasar.config file > boot:
 * boot: ['file', ...] // do not add ".js" extension to it.
 *
 * Boot files are your "main.js"
 **/
import lang from 'quasar/lang/es.js'
import iconSet from 'quasar/icon-set/material-icons.js'

import {Notify,Dialog,Loading,LoadingBar} from 'quasar'

export default { config: {"notify":{"position":"top-right","timeout":3500},"loadingBar":{"color":"primary"}},lang,iconSet,plugins: {Notify,Dialog,Loading,LoadingBar} }
